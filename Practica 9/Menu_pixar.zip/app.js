$('.menu').click(function(){
    $('.menu-desplegable').addClass('activo')
})

$('.dos').click(function(){
    $('.menu-desplegable').removeClass('activo')
})
